from fastapi import FastAPI, HTTPException
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
import uvicorn
import pydantic
import bcrypt
import user_db
import achievments_db
import quiz_db

app = FastAPI()

class User(BaseModel):
    username: str
    password: str

@app.get("/")
@app.post("/")
async def register(user_json: User):
    a = User.model_validate_json(user_json)
    hashed_password = bcrypt.hashpw(a.password.encode('utf-8'), bcrypt.gensalt())
    try:
        user_db.user_register(a.username, hashed_password)
        await RedirectResponse(url="http://127.0.0.1:8000/login")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/login")
@app.post("/login")
async def login(user_json: User):
    a = User.model_validate_json(user_json)
    try:
        user_db.user_login(a.username, bcrypt.hashpw(a.password.encode('utf-8'), bcrypt.gensalt()))
        await RedirectResponse(url="http://127.0.0.1:8000/profile")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/profile/{user_id}")
@app.post("/profile/{user_id}")
async def profile(user_id: int):



if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)