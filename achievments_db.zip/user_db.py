import psycopg2
import os
from psycopg2.extras import DictCursor

DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_NAME = os.getenv('DB_NAME', "mtc")
DB_USER = os.getenv('DB_USER', "postgres")
DB_PASS = os.getenv('DB_PASS', "karinaw475484")

def get_connection():
    return psycopg2.connect(dbname=DB_NAME,
                            user=DB_USER,
                            password=DB_PASS, 
                            host=DB_HOST, 
                            cursor_factory=DictCursor,
                            port=5432)

def create_table():
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users(
                    user_id SERIAL PRIMARY KEY,
                    username VARCHAR(15) UNIQUE NOT NULL,
                    password_hash VARCHAR(15) NOT NULL,
                    ac_creation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_activity TIMESTAMP,
                    points INTEGER,
                    quizes_done VARCHAR,
                    ach_done VARCHAR,
                    likes INTEGER,
                    dislikes INTEGER,
                    films_watched INTEGER
                );
            """)
            conn.commit()

def user_register(username, password_hash):
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO users(username, password_hash)
                VALUES(%s, %s)
            """, (username, password_hash))
            conn.commit()

def user_login(username, password_hash):
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT * FROM users
                WHERE username = %s AND password_hash = %s
            """, (username, password_hash))
            return cursor.fetchone()

def get_profile_by_id(user_id):
    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT * FROM users
                WHERE user_id = %s
            """, (user_id,))
            return cursor.fetchall()


if __name__ == "__main__":
    create_table()